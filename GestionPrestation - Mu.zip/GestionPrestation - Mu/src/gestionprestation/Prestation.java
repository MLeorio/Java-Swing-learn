/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionprestation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Nyaki SEMOU
 */
public class Prestation {

    public void PrestationUpdate(
            
            char operation,
            Integer id,
            String libelle,
            String date_emmission,
            String date_execution,
            Double tarif,
            Integer client,
            Integer agence,
            Integer agent
    ) {
        Connection con = MyConnect.getConnection();
        PreparedStatement ps = null;

        if (operation == 'i') {
            try {
                ps = con.prepareStatement("INSERT INTO prestation(libelle, date_emission, date_execution, tarif, ref_client, ref_agent, ref_agence) "
                        + "VALUES(?, ?, ?, ?, ?, ?, ?)");
                ps.setString(1, libelle);
                ps.setString(2, date_emmission);
                ps.setString(3, date_execution);
                ps.setDouble(4, tarif);
                ps.setInt(5, client);
                ps.setInt(6, agence);
                ps.setInt(7, agent);

                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Nouvelle prestation ajouter");
                }

            } catch (SQLException ex) {
                Logger.getLogger(Prestation.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        if (operation == 'u') {
            try {
                ps = con.prepareStatement("UPDATE prestation SET libelle = ?, date_emission = ?,"
                        + "date_execution = ?, tarif = ?, ref_client = ?, ref_agence = ?, ref_agent = ? WHERE id = ?");
                ps.setString(1, libelle);
                ps.setString(2, date_emmission);
                ps.setString(2, date_execution);
                ps.setDouble(3, tarif);
                ps.setInt(4, client);
                ps.setInt(5, agence);
                ps.setInt(7, agent);

                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Service mis a jour");
                }

            } catch (SQLException ex) {
                Logger.getLogger(Prestation.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        if (operation == 'd') {

            int YesOrNo = JOptionPane.showConfirmDialog(null, "Voulez-vous vraiment supprimer cette prestation ?",
                    "Supprimer une prestation", JOptionPane.OK_CANCEL_OPTION, 0);

            if (YesOrNo == JOptionPane.OK_OPTION) {
                try {
                    ps = con.prepareStatement("DELETE FROM prestation WHERE id = ?");
                    ps.setInt(1, id);

                    if (ps.executeUpdate() > 0) {
                        JOptionPane.showMessageDialog(null, "Prestation supprimer");
                    }

                } catch (SQLException ex) {
                    Logger.getLogger(Prestation.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    public void PrestationTable(JTable table, String valeurSearch) {
        Connection con = MyConnect.getConnection();
        PreparedStatement ps = null;

        try {
            ps = con.prepareStatement("SELECT * FROM prestation WHERE"
                    + "CONCAT (libelle, date_emission, date_execution, tarif) LIKE ?");
            
            ps.setString(1, "%" + valeurSearch + "%");

            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();

            Object[] row;

            while (rs.next()) {
                row = new Object[7];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getDouble(4);
                row[4] = rs.getInt(5);
                row[5] = rs.getInt(6);
                row[6] = rs.getInt(7);

                model.addRow(row);
            }

        } catch (SQLException ex) {
            Logger.getLogger(Prestation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    public void PrestationShowTable(JTable table) {
        Connection con = MyConnect.getConnection();
        PreparedStatement ps = null;

        try {
            ps = con.prepareStatement("SELECT * FROM prestation");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();

            Object[] row;

            while (rs.next()) {
                row = new Object[8];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                row[4] = rs.getDouble(5);
                row[5] = rs.getInt(6);
                row[6] = rs.getInt(7);
                row[7] = rs.getInt(8);

                model.addRow(row);
            }

        } catch (SQLException ex) {
            Logger.getLogger(Prestation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
