/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionprestation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Fernand Afanou
 */
public class Agence {

    public void AgenceUpdate(
            char operation,
            Integer id,
            String nom_agence,
            String quartier,
            String telephone
    ) {
        Connection con = MyConnect.getConnection();
        PreparedStatement ps = null;
        
        if (operation == 'i') {
            try {
                ps = con.prepareStatement("INSERT INTO agence(nom_agence, quartier, tel) VALUES(?, ?, ?)");
                ps.setString(1, nom_agence);
                ps.setString(2, quartier);
                ps.setString(3, telephone);

                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Agence ajouter");
                }

            } catch (SQLException ex) {
                Logger.getLogger(Agence.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        if (operation == 'u') {
            try {
                ps = con.prepareStatement("UPDATE agence SET nom_agence = ?, quartier = ?, tel = ? WHERE id = ?");
                ps.setString(1, nom_agence);
                ps.setString(2, quartier);
                ps.setString(3, telephone);
                ps.setInt(4, id);

                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Agence mis a jour");
                }

            } catch (SQLException ex) {
                Logger.getLogger(Agence.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        if (operation == 'd') {

            int YesOrNo = JOptionPane.showConfirmDialog(null, "Voulez-vous vraiment supprimer cete Agence ?",
                    "Supprimer une agence", JOptionPane.OK_CANCEL_OPTION, 0);

            if (YesOrNo == JOptionPane.OK_OPTION) {
                try {
                    ps = con.prepareStatement("DELETE FROM agence WHERE id = ?");
                    ps.setInt(1, id);
                    
                    if (ps.executeUpdate() > 0) {
                        JOptionPane.showMessageDialog(null, "Agence supprimer");
                    }

                } catch (SQLException ex) {
                    Logger.getLogger(Agence.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
    }
    
    public void AgenceTable(JTable table, String valeurSearch) {
        Connection con = MyConnect.getConnection();
        PreparedStatement ps = null;
        
        try {
            ps = con.prepareStatement("SELECT * FROM agence WHERE CONCAT (nom_agence, quartier, tel) LIKE ?");
            ps.setString(1, "%" + valeurSearch + "%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while (rs.next()) {                
                row = new Object[4];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                
                model.addRow(row);
            }
            
                    
        } catch (SQLException ex) {
            Logger.getLogger(Agence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
