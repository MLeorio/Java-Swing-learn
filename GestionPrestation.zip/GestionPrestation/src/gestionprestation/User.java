/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionprestation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Fernand Afanou
 */
public class User {

    public void UserUpdate(
            char operation,
            Integer id,
            String fnom,
            String fprenom,
            String fident,
            String fpass) {

        Connection con = MyConnect.getConnection();
        PreparedStatement ps = null;
        String fullname = fprenom + " " + fnom;

        if (operation == 'i') {
            try {
                ps = con.prepareStatement("INSERT INTO user(nom, ident, mdp) VALUES(?, ?, ?)");
                ps.setString(1, fullname);
                ps.setString(2, fident);
                ps.setString(3, fpass);

                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Nouveau utilisateur ajouter");
                }

            } catch (SQLException ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        if (operation == 'u') {
            try {
                ps = con.prepareStatement("UPDATE user SET nom = ?, ident = ?, mdp = ? WHERE id = ?");
                ps.setString(1, fullname);
                ps.setString(2, fident);
                ps.setString(3, fpass);
                ps.setInt(4, id);

                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Donnees utilisateur mis a jour");

                }
            } catch (SQLException ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        if (operation == 'd') {

            int YesOrNo = JOptionPane.showConfirmDialog(null, "Voulez-vous vraiment supprimer cet utilisateur ?",
                    "Supprimer un utilisateur", JOptionPane.OK_CANCEL_OPTION, 0);

            if (YesOrNo == JOptionPane.OK_OPTION) {
                try {
                    ps = con.prepareStatement("DELETE FROM user WHERE id = ?");

                    ps.setInt(1, id);
                    if (ps.executeUpdate() > 0) {
                        JOptionPane.showMessageDialog(null, "Utilisateur supprimer");
                    }

                } catch (SQLException ex) {
                    Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }
    
    public void UserTable(JTable table, String valeurSearch) {
        Connection con = MyConnect.getConnection();
        PreparedStatement ps = null;
        
        try {
            ps = con.prepareStatement("SELECT * FROM user WHERE CONCAT (nom, ident) LIKE ?");
            ps.setString(1, "%" + valeurSearch + "%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while (rs.next()) {                
                row = new Object[4];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                
                model.addRow(row);
            }
            
                    
        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}