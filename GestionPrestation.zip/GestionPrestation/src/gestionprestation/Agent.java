/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionprestation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Fernand Afanou
 */
public class Agent {
    public void AgentUpdate(
            char operation,
            Integer id,
            String nom_agent,
            String prenom_agent,
            String tel_agent,
            String sexe_agent,
            String adresse_agent,
            Integer ref_agence
    ) {
        Connection con = MyConnect.getConnection();
        PreparedStatement ps = null;
        
        if (operation == 'i') {
            try {
                ps = con.prepareStatement("INSERT INTO agent(nom, prenom, tel, sexe, adresse, ref_agence) VALUES(?, ?, ?, ?, ?, ?)");
                ps.setString(1, nom_agent);
                ps.setString(2, prenom_agent);
                ps.setString(3, tel_agent);
                ps.setString(4, sexe_agent);
                ps.setString(5, adresse_agent);
                ps.setInt(6, ref_agence);

                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Agent ajouter");
                }

            } catch (SQLException ex) {
                Logger.getLogger(Agent.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        if (operation == 'u') {
            try {
                ps = con.prepareStatement("UPDATE agent SET nom = ?, prenom = ?, tel = ?, sexe = ?, adresse = ?, ref_agence = ? WHERE id = ?");
                ps.setString(1, nom_agent);
                ps.setString(2, prenom_agent);
                ps.setString(3, tel_agent);
                ps.setString(4, sexe_agent);
                ps.setString(5, adresse_agent);
                ps.setInt(6, ref_agence);
                ps.setInt(7, id);

                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Agent mis a jour");
                }

            } catch (SQLException ex) {
                Logger.getLogger(Agence.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        if (operation == 'd') {

            int YesOrNo = JOptionPane.showConfirmDialog(null, "Voulez-vous vraiment supprimer cet agent ?",
                    "Supprimer un agent", JOptionPane.OK_CANCEL_OPTION, 0);

            if (YesOrNo == JOptionPane.OK_OPTION) {
                try {
                    ps = con.prepareStatement("DELETE FROM agent WHERE id = ?");
                    ps.setInt(1, id);
                    
                    if (ps.executeUpdate() > 0) {
                        JOptionPane.showMessageDialog(null, "Agence supprimer");
                    }

                } catch (SQLException ex) {
                    Logger.getLogger(Agence.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void AgentTable(JTable table, String valeurSearch) {
        Connection con = MyConnect.getConnection();
        PreparedStatement ps = null;
        
        try {
            ps = con.prepareStatement("SELECT * FROM agent WHERE CONCAT (nom, prenom, tel, sexe, adresse) LIKE ?");
            ps.setString(1, "%" + valeurSearch + "%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while (rs.next()) {                
                row = new Object[7];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                row[4] = rs.getString(5);
                row[5] = rs.getString(6);
                row[6] = rs.getInt(7);
                
                model.addRow(row);
            }
            
                    
        } catch (SQLException ex) {
            Logger.getLogger(Agent.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void AgentShowTable(JTable table) {
        Connection con = MyConnect.getConnection();
        PreparedStatement ps = null;
        
        try {
            ps = con.prepareStatement("SELECT * FROM agent");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while (rs.next()) {                
                row = new Object[7];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                row[4] = rs.getString(5);
                row[5] = rs.getString(6);
                row[6] = rs.getInt(7);
                
                model.addRow(row);
            }
            
                    
        } catch (SQLException ex) {
            Logger.getLogger(Agent.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
