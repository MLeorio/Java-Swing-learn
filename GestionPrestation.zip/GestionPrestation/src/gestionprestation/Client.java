/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionprestation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Fernand Afanou
 */
public class Client {

    public void ClientUpdate(
            char operation,
            Integer id,
            String nom_client,
            String prenom_cllient,
            String tel_client,
            String sexe_client,
            String adresse_client
    ) {
        Connection con = MyConnect.getConnection();
        PreparedStatement ps = null;

        if (operation == 'i') {
            try {
                ps = con.prepareStatement("INSERT INTO clients(nom, prenom, tel, sexe, adresse) VALUES(?, ?, ?, ?, ?)");
                ps.setString(1, nom_client);
                ps.setString(2, prenom_cllient);
                ps.setString(3, tel_client);
                ps.setString(4, sexe_client);
                ps.setString(5, adresse_client);

                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Client ajouter");
                }

            } catch (SQLException ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        if (operation == 'u') {
            try {
                ps = con.prepareStatement("UPDATE clients SET nom = ?, prenom = ?, tel = ?, sexe = ?, adresse = ? WHERE id = ?");
                ps.setString(1, nom_client);
                ps.setString(2, prenom_cllient);
                ps.setString(3, tel_client);
                ps.setString(4, sexe_client);
                ps.setString(5, adresse_client);
                ps.setInt(7, id);

                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Client mis a jour");
                }

            } catch (SQLException ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        if (operation == 'd') {

            int YesOrNo = JOptionPane.showConfirmDialog(null, "Voulez-vous vraiment supprimer cet client ?",
                    "Supprimer un client", JOptionPane.OK_CANCEL_OPTION, 0);

            if (YesOrNo == JOptionPane.OK_OPTION) {
                try {
                    ps = con.prepareStatement("DELETE FROM clients WHERE id = ?");
                    ps.setInt(1, id);

                    if (ps.executeUpdate() > 0) {
                        JOptionPane.showMessageDialog(null, "Client supprimer");
                    }

                } catch (SQLException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    public void ClientTable(JTable table, String valeurSearch) {
        Connection con = MyConnect.getConnection();
        PreparedStatement ps = null;

        try {
            ps = con.prepareStatement("SELECT * FROM clients WHERE CONCAT (nom, prenom, tel, sexe, adresse) LIKE ?");
            ps.setString(1, "%" + valeurSearch + "%");

            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();

            Object[] row;

            while (rs.next()) {
                row = new Object[6];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                row[4] = rs.getString(5);
                row[5] = rs.getString(6);

                model.addRow(row);
            }

        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

     public void ClientShowTable(JTable table) {
        Connection con = MyConnect.getConnection();
        PreparedStatement ps = null;

        try {
            ps = con.prepareStatement("SELECT * FROM clients");

            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();

            Object[] row;

            while (rs.next()) {
                row = new Object[6];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                row[4] = rs.getString(5);
                row[5] = rs.getString(6);

                model.addRow(row);
            }

        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
